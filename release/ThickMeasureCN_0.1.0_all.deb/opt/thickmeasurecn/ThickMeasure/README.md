# ThickMeasure

ThickMeasure is a Raspberry Pi touchscreen app for pulse-echo ultrasonic thickness measurement using a lit3rick single-channel ultrasonic board.

The app can:

- program the lit3rick FPGA RAM automatically when the app opens
- acquire ultrasonic RF traces from lit3rick over SPI/I2C
- show a high-contrast outdoor-friendly live plot
- calibrate sound velocity from a reference sample
- track the selected first and second back-wall echoes during measurement
- save the last 10 thickness readings to CSV

## Hardware

- Raspberry Pi 5, or another Raspberry Pi with SPI and I2C enabled
- lit3rick ultrasonic controller board
- ultrasonic probe connected to the lit3rick board
- optional 5.5 inch or 7 inch Raspberry Pi touchscreen

## Repository Contents

```text
app.py                         English ThickMeasure GUI app
app_ch.py                      Chinese GMRI测厚软件 GUI app
run_ThickMeasure.sh            app launcher
run_ThickMeasure_CH.sh         Chinese app launcher
setup.sh                       Raspberry Pi installer
tools/build_deb.py             builds the ThickMeasureCN .deb installer
packaging/deb                  Debian package control scripts
logo.png                       blue GMRI logo used by the desktop launcher
logo-app.png                   yellow GMRI logo used inside the app as Close
ThickMeasure.desktop           desktop launcher template
ThickMeasure_CH.desktop        Chinese desktop launcher template
LICENSE                        MIT license
lit3rick/program               lit3rick FPGA programming files
lit3rick/py_fpga               lit3rick Python control and acquisition files
```

## Install On A New Raspberry Pi

For the Chinese version, use the `.deb` installer on Raspberry Pi OS:

```bash
sudo apt install ./ThickMeasureCN_0.1.0_all.deb
```

The current prebuilt installer is stored in this repository at:

```text
release/ThickMeasureCN_0.1.0_all.deb
```

This installs ThickMeasureCN into `/opt/thickmeasurecn/ThickMeasure`, installs the GMRI logo as the Linux app icon, creates the `ThickMeasureCN` desktop icon, and sets the Chinese app as the default startup app.

To build the `.deb` package from this repository:

```bash
python3 tools/build_deb.py
```

The package is written to:

```text
dist/ThickMeasureCN_0.1.0_all.deb
```

Note: a `.deb` package is convenient for Linux installation, but it is not an encrypted or secret format. People can still inspect package contents with standard Linux tools.

For manual installation, clone this repository on the Raspberry Pi:


```bash
cd ~
git clone https://github.com/ultrasunix/ThickMeasure.git
cd ThickMeasure
```

Run the setup script:

```bash
bash setup.sh
```

The installer will:

- install required Python and Raspberry Pi packages
- enable SPI and I2C using `raspi-config` when available
- copy the app into `/home/<user>/ThickMeasure`
- copy the bundled lit3rick `program` and `py_fpga` folders
- build and install WiringPi when `libwiringPi.so` is missing
- install `lit3prog` into `/usr/local/bin`
- create a passwordless sudo rule only for `prog_ram.sh`
- create a boot-time service that runs `prog_ram.sh`
- create a desktop launcher
- create a Chinese desktop launcher
- create an autostart entry so ThickMeasure opens after desktop login

If you installed an older version and files disappeared from `~/ThickMeasure`, re-clone the repository or run `git restore .` from inside the clone, then run the updated `bash setup.sh` again.

Reboot after installation:

```bash
sudo reboot
```

## Manual Launch

If the app does not open automatically, run:

```bash
~/ThickMeasure/run_ThickMeasure.sh
```

or double-click the `ThickMeasure` desktop icon.

To launch the Chinese version, run:

```bash
~/ThickMeasure/run_ThickMeasure_CH.sh
```

or double-click the `ThickMeasureCN` desktop icon.

## Typical Use

1. Connect the lit3rick board, probe, and sample.
2. Open ThickMeasure.
3. Wait for the status message `Board ready - run Calibration`.
4. Enter `Ref. Thickness` in mm.
5. Enter `Ref. Velocity` in m/s. This is only a reference value to help locate echoes.
6. Press `Calibration`.
7. Check the two red cursors on the first and second back-wall echoes.
8. If needed, tap the first and second back-wall echoes on the plot to adjust the cursors.
9. Press `Start`.
10. Press `Stop` when finished.
11. Press `Save` to save the most recent thickness readings.

## Touchscreen Numeric Keypad

Tap the `Ref. Thickness` or `Ref. Velocity` input box to open the built-in numeric keypad.

The keypad supports:

- digits
- decimal point
- backspace
- clear
- cancel
- OK

## Saved Data

CSV files are saved in:

```text
/home/<user>/ThickMeasure/sdata-ThickMeasure
```

File names use this format:

```text
sdata-thickness-YYYY-MM-DD-HH-MM-SS.csv
```

Each CSV contains exactly 10 rows. If fewer than 10 measurements were collected, the remaining rows are filled with zeros.

## Notes On Calibration

For pulse-echo measurement, the ultrasound travels to the back wall and returns, so the path length is:

```text
2 * thickness
```

The calibrated velocity is calculated from:

```text
velocity = 2 * reference_thickness / echo_spacing_time
```

The reference velocity does not need to be exact. It only helps the app locate a reasonable first and second back-wall echo pair.

## Troubleshooting

### Remote I/O error

This usually means the lit3rick board is not programmed or the I2C/SPI connection is not ready.

The app tries to run this automatically:

```bash
sudo /home/<user>/ThickMeasure/lit3rick/program/prog_ram.sh
```

You can test it manually:

```bash
cd ~/ThickMeasure/lit3rick/program
sudo ./prog_ram.sh
```

Successful programming should show:

```text
cdone: high
```

On fresh Raspberry Pi OS installs, the old WiringPi `gpio` command may be missing. `setup.sh` installs a `/usr/local/bin/gpio` compatibility wrapper for the lit3rick programming script. If you still see `gpio: command not found`, pull the latest repository and rerun `bash setup.sh`.

`setup.sh` also builds `lit3prog` from source on the Raspberry Pi and installs it into `/usr/local/bin/lit3prog` as a normal root-owned executable. Building it locally avoids architecture and shared-library mismatches on newer 64-bit Raspberry Pi OS installs. If you see `lit3prog: command not found` or `cannot execute: required file not found`, pull the latest repository and rerun `bash setup.sh`.

`setup.sh` builds WiringPi automatically when `libwiringPi.so` is missing. It also enables the `thickmeasure-lit3rick.service` systemd service, which runs `prog_ram.sh` at boot so the lit3rick board is programmed before normal use.

### SPI or I2C not enabled

Run:

```bash
sudo raspi-config
```

Then enable:

- Interface Options > SPI
- Interface Options > I2C

Reboot afterwards.

### App does not start on boot

Check the autostart entry:

```bash
ls ~/.config/autostart/ThickMeasure.desktop
```

Manual launch:

```bash
~/ThickMeasure/run_ThickMeasure.sh
```

### No echoes detected

Check:

- probe connection
- couplant
- lit3rick programming status
- gain/contact condition
- whether the first and second back-wall cursors are correctly selected after calibration
